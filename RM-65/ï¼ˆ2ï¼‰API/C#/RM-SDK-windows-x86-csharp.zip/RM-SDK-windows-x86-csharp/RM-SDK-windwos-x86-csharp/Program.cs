﻿using System;
using System.Runtime.InteropServices;
using System.Threading;
namespace RM_SDK_windwos_x86_csharp
{
    class Program
    {

        const int RMERR_SUCC = 0;

        const int ARM_DOF = 7;

        const int None_Mode = 0;

        const int Joint_Mode = 1;

        const int Line_Mode = 2;

        const int Circle_Mode = 3;

        const int X_Dir = 0;       //X轴方向
        const int Y_Dir = 1;       //Y轴方向
        const int Z_Dir = 2;       //Z轴方向

        const int RX_Rotate = 0;       //RX轴方向
        const int RY_Rotate = 1;      //RY轴方向
        const int RZ_Rotate = 2;       //RZ轴方向

        //uint m_sockhandler;

        [StructLayout(LayoutKind.Sequential)]
        public struct POSE2
        {
            //位置
            public float px;
            public float py;
            public float pz;
            //四元数
            public float w;
            public float x;
            public float Y;
            public float z;
        }
        [StructLayout(LayoutKind.Sequential)]
        public struct ORT
        {
            public float rx;
            public float ry;
            public float rz;
        }
        [StructLayout(LayoutKind.Sequential)]
        public struct POSE
        {
            //位置
            public float px;
            public float py;
            public float pz;
            //欧拉角
            public float rx;
            public float ry;
            public float rz;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct KINEMATIC
        {
            public POSE2 pose;
            public ORT ort;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct FRAME_NAME
        {
            //位置
            [MarshalAs(UnmanagedType.ByValArray, SizeConst =50)]
            public char[] name;
        }


        [StructLayout(LayoutKind.Sequential)]
        public struct FRAME
        {
        //位置
            public FRAME_NAME frame_name;
            public POSE pose;
            public float payload;
            public float x;
            public float y;
            public float z;
        }
        [StructLayout(LayoutKind.Sequential)]
        public struct JOINT_STATE
        {
            //位置
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            public float[] joint;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            public float[] temperature;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            public float[] voltage;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            public float[] current;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            public byte[] en_state;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            public UInt16[] err_flag;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            public UInt16 sys_err;
        }

        [DllImport("RM_API_C.dll", EntryPoint = "RM_API", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern void RM_API(int Joint_Number);

        //初始化机械臂控制库
        [DllImport("RM_API_C.dll", EntryPoint = "Arm_Socket_Start", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern uint Arm_Socket_Start([MarshalAs(UnmanagedType.LPStr)] string ip, int arm_prot, int recv_timeout);


        [DllImport("RM_API_C.dll", EntryPoint = "Arm_Sockrt_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Arm_Sockrt_State(uint ArmSocket);

        [DllImport("RM_API_C.dll", EntryPoint = "Arm_Socket_Close", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern void Arm_Socket_Close(uint ArmSocket);


        [DllImport("RM_API_C.dll", EntryPoint = "Arm_Socket_Buffer_Clear", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern void Arm_Socket_Buffer_Clear(uint ArmSocket);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Joint_Speed", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Joint_Speed(uint ArmSocket, byte joint_num, float speed, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "API_Version", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr API_Version();

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Joint_Acc", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Joint_Acc(uint ArmSocket, byte joint_num, float acc, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Parser_Joint_Acc", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Parser_Joint_Acc([MarshalAs(UnmanagedType.LPStr)] string msg);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Joint_Min_Pos", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Joint_Min_Pos(uint ArmSocket, byte joint_num, float joint, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Parser_Joint_Min_Pos", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Parser_Joint_Min_Pos([MarshalAs(UnmanagedType.LPStr)] string msg);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Joint_Max_Pos", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Joint_Max_Pos(uint ArmSocket, byte joint_num, float joint, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Parser_Joint_Max_Pos", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Parser_Joint_Max_Pos([MarshalAs(UnmanagedType.LPStr)] string msg);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Joint_EN_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Joint_EN_State(uint ArmSocket, byte joint_num, bool state, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Joint_Zero_Pos", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Joint_Zero_Pos(uint ArmSocket, byte joint_num, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Joint_Err_Clear", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Joint_Err_Clear(uint ArmSocket, byte joint_num, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Start_Calibrate", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Start_Calibrate(uint ArmSocket, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Stop_Calibrate", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Stop_Calibrate(uint ArmSocket, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_Calibrate_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Calibrate_State(uint ArmSocket, [In, Out] float[] joint_state, [In, Out] UInt16[] state,ref int time, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_Joint_Speed", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Joint_Speed(uint ArmSocket, [In, Out] float[] speed);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_Joint_Acc", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Joint_Acc(uint ArmSocket, [In, Out] float[] acc);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_Joint_Min_Pos", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Joint_Min_Pos(uint ArmSocket, [In, Out] float[] min_joint);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Joint_Max_Pos", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Joint_Max_Pos(uint ArmSocket, [In, Out] float[] max_joint);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Joint_Err_Flag", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Joint_Err_Flag(uint ArmSocket, [In, Out] UInt16[] state);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Joint_Software_Version", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Joint_Software_Version(uint ArmSocket, [In, Out] float[] version);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Arm_Line_Speed", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Arm_Line_Speed(uint ArmSocket, float speed, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Arm_Line_Acc", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Arm_Line_Acc(uint ArmSocket, float acc, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Arm_Angular_Speed", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Arm_Angular_Speed(uint ArmSocket, float speed, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Arm_Angular_Acc", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Arm_Angular_Acc(uint ArmSocket, float acc, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_Arm_Line_Speed", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Arm_Line_Speed(uint ArmSocket, ref float speed);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_Arm_Line_Acc", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Arm_Line_Acc(uint ArmSocket, ref float acc);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Arm_Angular_Speed", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Arm_Angular_Speed(uint ArmSocket, ref float speed);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Arm_Angular_Acc", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Arm_Angular_Acc(uint ArmSocket, ref float acc);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Arm_Tip_Init", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Arm_Tip_Init(uint ArmSocket, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Collision_Stage", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Collision_Stage(uint ArmSocket, int stage, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Collision_Stage", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Collision_Stage(uint ArmSocket, ref int stage);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_DH_Data", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_DH_Data(uint ArmSocket, float lsb, float lse, float lew, float lwt, float d3, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_DH_Data", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_DH_Data(uint ArmSocket, ref float lsb, ref float lse, ref float lew, ref float lwt, ref float d3);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Joint_Zero_Offset", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Joint_Zero_Offset(uint ArmSocket, [In, Out] float[] offset, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Arm_Dynamic_Parm", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Arm_Dynamic_Parm(uint ArmSocket, [In, Out] float[] parm, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Tool_Software_Version", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Tool_Software_Version(ref int version);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Arm_Servo_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Arm_Servo_State(uint ArmSocket, bool cmd, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Auto_Set_Tool_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int  Auto_Set_Tool_Frame(uint ArmSocket, byte point_num, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Generate_Auto_Tool_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Generate_Auto_Tool_Frame([MarshalAs(UnmanagedType.LPStr)] string name, float payload, float x, float y, float z, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Manual_Set_Tool_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Manual_Set_Tool_Frame(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string name, POSE pose, float payload, float x, float y, float z, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Change_Tool_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Change_Tool_Frame(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string name, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Delete_Tool_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Delete_Tool_Frame(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string name, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Payload", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Payload(uint ArmSocket, int payload, float cx, float cy, float cz, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_None_Payload", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_None_Payload(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Current_Tool_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Current_Tool_Frame(uint ArmSocket, ref FRAME tool);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_Given_Tool_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Given_Tool_Frame(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string name,ref FRAME tool);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_All_Tool_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_All_Tool_Frame(uint ArmSocket, [In, Out] FRAME_NAME[] names);


        [DllImport("RM_API_C.dll", EntryPoint = "Auto_Set_Work_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Auto_Set_Work_Frame(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string name, byte point_num, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Manual_Set_Work_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Manual_Set_Work_Frame(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string name, POSE pose, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Change_Work_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Change_Work_Frame(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string name, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Delete_Work_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Delete_Work_Frame(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string name, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Current_Work_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Current_Work_Frame(uint ArmSocket, ref FRAME frame);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_Given_Work_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Given_Work_Frame(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string name, ref POSE pose);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_All_Work_Frame", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_All_Work_Frame(uint ArmSocket, [In, Out] FRAME_NAME[] names);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Current_Arm_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Current_Arm_State(uint ArmSocket, [In, Out] float[] joint, ref POSE pose, ref UInt16 Arm_Err, ref UInt16 Sys_Err);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_Current_Arm_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Joint_Temperature(uint ArmSocket, [In, Out] float[] temperature);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Joint_Current", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Joint_Current(uint ArmSocket, [In, Out] float[] current);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_Joint_Voltage", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Joint_Voltage(uint ArmSocket, [In, Out] float[] voltage);



        [DllImport("RM_API_C.dll", EntryPoint = "Get_Arm_All_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Arm_All_State(uint ArmSocket, ref JOINT_STATE joint_state);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Arm_Plan_Num", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Arm_Plan_Num(uint ArmSocket, ref int plan);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Arm_Init_Pose", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Arm_Init_Pose(uint ArmSocket, [In, Out]  float[] target, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Arm_Init_Pose", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Arm_Init_Pose(uint ArmSocket, [In, Out] float[] joint);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Install_Pose", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Install_Pose(float x, float y, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Movej_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Movej_Cmd(uint ArmSocket, [In, Out] float[] joint, byte v, float r, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Movel_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Movel_Cmd(uint ArmSocket, POSE pose, byte v, float r, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Movec_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern  int Movec_Cmd(uint ArmSocket, POSE pose_via, POSE pose_to, byte v, float r, byte loop, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Movej_CANFD", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Movej_CANFD(uint ArmSocket, [In, Out] float[] joint, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Movep_CANFD", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Movep_CANFD(uint ArmSocket, POSE pose, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Move_Stop_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Move_Stop_Cmd(uint ArmSocket, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Move_Pause_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Move_Pause_Cmd(uint ArmSocket, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Move_Continue_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Move_Continue_Cmd(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Clear_Current_Trajectory", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Clear_Current_Trajectory(uint ArmSocket, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Clear_All_Trajectory", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Clear_All_Trajectory(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Current_Trajectory", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Current_Trajectory(uint ArmSocket, ref int type, [In, Out] float[] data);


        [DllImport("RM_API_C.dll", EntryPoint = "Add_Waypoint", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Add_Waypoint(uint ArmSocket, [In, Out] float[] joint, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Start_Waypoint", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Start_Waypoint(uint ArmSocket, int frq, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Clear_Waypoint", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Clear_Waypoint(uint ArmSocket, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Stop_Waypoint", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Stop_Waypoint(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Movej_P_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Movej_P_Cmd(uint ArmSocket, POSE pose, byte v, float r, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Timer", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Timer(uint ArmSocket, int time, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Joint_Teach_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Joint_Teach_Cmd(uint ArmSocket, byte num, byte direction, byte v, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Pos_Teach_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Pos_Teach_Cmd(uint ArmSocket, int type, byte direction, byte v, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Teach_Stop_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Teach_Stop_Cmd(uint ArmSocket, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Joint_Step_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Joint_Step_Cmd(uint ArmSocket, byte num, float step, byte v, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Joint_Step_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Pos_Step_Cmd(uint ArmSocket, int type, float step, byte v, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Ort_Step_Cmd", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Ort_Step_Cmd(uint ArmSocket, int type, float step, byte v, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Controller_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Controller_State(uint ArmSocket, ref float voltage, ref float current, ref float temperature, ref UInt16 sys_err);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_WiFi_AP_Data", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_WiFi_AP_Data(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string  wifi_name, [MarshalAs(UnmanagedType.LPStr)] string password);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_WiFI_STA_Data", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_WiFI_STA_Data(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string router_name, [MarshalAs(UnmanagedType.LPStr)] string password);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_USB_Data", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_USB_Data(uint ArmSocket, int baudrate);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_RS485", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_RS485(uint ArmSocket, int baudrate);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Ethernet", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Ethernet(uint ArmSocket);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Arm_Power", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Arm_Power(uint ArmSocket, bool cmd, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Arm_Power_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Arm_Power_State(uint ArmSocket, ref int power);


        [DllImport("RM_API_C.dll", EntryPoint = "Clear_System_Err", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Clear_System_Err(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Arm_Hardware_Version", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Arm_Hardware_Version(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string version);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Arm_Software_Version", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Arm_Software_Version(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string plan_version, [MarshalAs(UnmanagedType.LPStr)] string ctrl_version);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_Log_File", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Log_File(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_System_Runtime", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_System_Runtime(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string state, ref int day, ref int hour, ref int min, ref int sec);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_System_Runtime", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Clear_System_Runtime(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Joint_Odom", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Joint_Odom(uint ArmSocket, [MarshalAs(UnmanagedType.LPStr)] string state, [In, Out] float[] odom);


        [DllImport("RM_API_C.dll", EntryPoint = "Clear_Joint_Odom", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Clear_Joint_Odom(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_High_Speed_Eth", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_High_Speed_Eth(uint ArmSocket, byte num, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_IO_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_IO_State(uint ArmSocket, int IO, byte num, ref byte state);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_DI_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_IO_State(uint ArmSocket, int IO, byte num, bool state, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_IO_Input", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_IO_Input(uint ArmSocket, ref byte DI_state, ref float AI_voltage);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_IO_Output", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_IO_Output(uint ArmSocket, ref byte DO_state, ref float AO_voltage);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Tool_DO_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Tool_DO_State(uint ArmSocket, byte num, bool state, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Tool_IO_Mode", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int  Set_Tool_IO_Mode(uint ArmSocket, byte num, bool state, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Tool_IO_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Tool_IO_State(uint ArmSocket, [In, Out] float[] IO_Mode, [In, Out] float[] IO_State);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Tool_Voltage", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Tool_Voltage(uint ArmSocket, byte type, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Tool_Voltage", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Tool_Voltage(uint ArmSocket, ref byte voltage);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Gripper_Route", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Gripper_Route(uint ArmSocket, int min_limit, int max_limit, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Gripper_Release", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Gripper_Release(uint ArmSocket, int speed, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Gripper_Release", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Gripper_Pick(uint ArmSocket, int speed, int force, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Gripper_Pick_On", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Gripper_Pick_On(uint ArmSocket, int speed, int force, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Gripper_Position", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Gripper_Position(uint ArmSocket, int position, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Start_Drag_Teach", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Start_Drag_Teach(uint ArmSocket, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Stop_Drag_Teach", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Stop_Drag_Teach(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Run_Drag_Trajectory", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Run_Drag_Trajectory(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Pause_Drag_Trajectory", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Pause_Drag_Trajectory(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Continue_Drag_Trajectory", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Continue_Drag_Trajectory(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Continue_Drag_Trajectory", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Stop_Drag_Trajectory(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Drag_Trajectory_Origin", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Drag_Trajectory_Origin(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Start_Multi_Drag_Teach", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Start_Multi_Drag_Teach(uint ArmSocket, int mode, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Force_Postion", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Force_Postion(uint ArmSocket, int mode, int force_level, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Stop_Force_Postion", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Stop_Force_Postion(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Force_Data", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Force_Data(uint ArmSocket, [In, Out] float[] Force);


        [DllImport("RM_API_C.dll", EntryPoint = "Clear_Force_Data", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Clear_Force_Data(uint ArmSocket, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Force_Sensor", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Force_Sensor(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Manual_Set_Force", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Manual_Set_Force(uint ArmSocket, int type, [In, Out] float[] joint);


        [DllImport("RM_API_C.dll", EntryPoint = "Stop_Set_Force_Sensor", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Stop_Set_Force_Sensor(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Hand_Posture", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Hand_Posture(uint ArmSocket, int posture_num, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Hand_Seq", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Hand_Seq(uint ArmSocket, int seq_num, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Hand_Angle", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Hand_Angle(uint ArmSocket, [In, Out] int[] angle, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Hand_Speed", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Hand_Speed(uint ArmSocket, int speed, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Hand_Force", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Hand_Force(uint ArmSocket, int force, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_PWM", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_PWM(uint ArmSocket, int Frq, int Dpulse, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Stop_PWM", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Stop_PWM(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Fz", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Fz(uint ArmSocket, ref float Fz);


        [DllImport("RM_API_C.dll", EntryPoint = "Clear_Fz", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern  int Clear_Fz(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Auto_Set_Fz", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Auto_Set_Fz(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Manual_Set_Fz", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Manual_Set_Fz(uint ArmSocket, [In, Out] float[] joint1, [In, Out] float joint2);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Modbus_Mode", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Modbus_Mode(uint ArmSocket, int port, int baudrate, int timeout, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Close_Modbus_Mode", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Close_Modbus_Mode(uint ArmSocket, int port, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Read_Coils", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Read_Coils(uint ArmSocket, int port,int address,int num,int device,ref int coils_data);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Read_Input_Status", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Read_Input_Status(uint ArmSocket, int port, int address, int num, int device, ref int coils_data);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Read_Holding_Registers", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Read_Holding_Registers(uint ArmSocket, int port, int address, int device, ref int coils_data);

        [DllImport("RM_API_C.dll", EntryPoint = "Get_Read_Input_Registers", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Read_Input_Registers(uint ArmSocket, int port, int address, int device, ref int coils_data);


        [DllImport("RM_API_C.dll", EntryPoint = "Write_Single_Coil", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Write_Single_Coil(uint ArmSocket, int port, int address, int data, int device, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Write_Coils", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Write_Coils(uint ArmSocket, int port, int address, int num, ref byte coils_data, int device, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Write_Single_Register", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Write_Single_Register(uint ArmSocket, int port, int address, int data, int device, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Write_Registers", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Write_Registers(uint ArmSocket, int port, int address, int num, ref byte single_data, int device, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Vehicle", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Vehicle(uint ArmSocket, int speed, int angular, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Lift", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Lift(uint ArmSocket, int height, int speed, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Lift_Speed", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Lift_Speed(uint ArmSocket, int speed, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Set_Lift_Speed", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Lift_Height(uint ArmSocket, int height, int speed, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Lift_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Lift_State(uint ArmSocket, ref int height, ref int current, ref int err_flag);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Car_Move", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Car_Move(uint ArmSocket, int linear, int angular, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Car_Navigation_Speed", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Car_Navigation_Speed(uint ArmSocket, int speed, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Car_Navigation_Mode", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Car_Navigation_Mode(uint ArmSocket, int mode, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Get_Car_State", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Get_Car_State(uint ArmSocket, ref int volume, ref int voltage, ref int current, ref int car_err, ref int car_state, ref int station);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Car_Charge", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Car_Charge(uint ArmSocket, int charge_state, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Set_Car_Station_Num", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Set_Car_Station_Num(uint ArmSocket, int charge_state, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Start_Force_Position_Move", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Start_Force_Position_Move(uint ArmSocket, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Force_Position_Move_POSE", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Force_Position_Move_POSE(uint ArmSocket, POSE pose, byte sensor, byte mode, int dir, float force, bool block);


        [DllImport("RM_API_C.dll", EntryPoint = "Force_Position_Move_Joint", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Force_Position_Move_Joint(uint ArmSocket, ref float joint, byte sensor, byte mode, int dir, float force, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "Stop_Force_Postion_Move", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int Stop_Force_Postion_Move(uint ArmSocket, bool block);

        [DllImport("RM_API_C.dll", EntryPoint = "setAngle", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern void setAngle(uint ArmSocket, float x, float y);

        [DllImport("RM_API_C.dll", EntryPoint = "setLwt", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern void setLwt(uint ArmSocket, int type);


        [DllImport("RM_API_C.dll", EntryPoint = "Forward_Kinematics", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern  KINEMATIC Forward_Kinematics(uint ArmSocket, [In,Out] float[] joint);

        [DllImport("RM_API_C.dll", EntryPoint = "inverse_kinematics", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl)]
        public static extern int inverse_kinematics(uint ArmSocket, [In, Out] float[] q_in, ref KINEMATIC q_pose, [In, Out]  float[] q_out,uint  flag);

        static void Main(string[] args)
        {
            Console.WriteLine("this is RM-ROBOT!");
            //int result = 0xffff;
            float[] joint = new float[ARM_DOF];
            float speed = 0 ;
            //初始化为六轴版本机器人
            RM_API(65);

            //获取API版本
            IntPtr pRet = API_Version();
            string version = Marshal.PtrToStringAnsi(pRet);
            Console.Out.WriteLine("RM-ROBOT API_Version={0}", version);

            //通过IP端口连接机械臂
            uint m_sockhandler =  Arm_Socket_Start("192.168.1.17", 8080, 30);
            if (m_sockhandler > 0) ;
            {
                Console.Out.WriteLine("Socket connection successful");
                
                if (Get_Joint_Speed(m_sockhandler, joint) == RMERR_SUCC)
                    Console.Out.WriteLine("RM-ROBOT Get_Joint_Speed value={0};{1};{2};{3};{4};{5}", joint[0], joint[1], joint[2], joint[3], joint[4], joint[5]);

                
                if(Get_Arm_Line_Speed(m_sockhandler, ref speed) == RMERR_SUCC) 
                    Console.Out.WriteLine("RM-ROBOT Get_Joint_Speed value={0}", speed);

                if (Arm_Sockrt_State(m_sockhandler) == RMERR_SUCC)
                    Console.Out.WriteLine("Arm_Sockrt_State connect success");

                if (Set_Arm_Tip_Init(m_sockhandler, true) == RMERR_SUCC)
                    Console.Out.WriteLine("Set_Arm_Tip_Init success");

                while (true)
                {
                    Thread.Sleep(2000);
                }
                Arm_Socket_Close(m_sockhandler);
            }
        }
    }
}
